import React from 'react'

export default function Address() {
    return (
      <div>
      <h3>Adresse:10 impasse des jardins kalaat andalous </h3>
      </div>
    );
  }