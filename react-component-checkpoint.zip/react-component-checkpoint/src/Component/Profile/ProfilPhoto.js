import React from 'react';

const ProfilPhoto = () => {
    return (
    <div className= "Photo">
    <img className= "Photo" src ="./rami.jpg" alt ="profilphoto" />
    </div>
    )
   };
   export default ProfilPhoto;