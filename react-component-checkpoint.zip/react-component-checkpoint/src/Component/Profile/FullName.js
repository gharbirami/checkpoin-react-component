import React from 'react'

export default function FullName() {
    return (
      <div>
      <h1>Rami Gharbi </h1>
      </div>
    );
  }